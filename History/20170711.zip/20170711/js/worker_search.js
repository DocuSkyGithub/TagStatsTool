/* Receive parameters from window, then return the result */
importScripts("./general.js", "./searchgram.js");
self.addEventListener("message", function(e){
	var params = e.data;
	var termlists, doclist = params.docs;
	var min = 1, max = 20;	// 20170331
	var type = params.type;
	var leninfo = [];
	var vlist = {}, vl_tmp, vlistinfo;
	var i, li, tagname, idcatpair, tmp_wordresult;
	
	// Form vocabulary list
	if(type === "xmltag"){
		for(i = 0, li = params.xmltagginginfo.tagnames.length; i < li; i++){
			tagname = params.xmltagginginfo.tagnames[i];
			if(params.xmltagginginfo.filtermap[tagname] !== undefined){
				vl_tmp = new VocabularyList();
				vlistinfo = vl_tmp.addCategory(tagname, params.xmltagginginfo.filterlist[params.xmltagginginfo.filtermap[tagname]], /\r\n|\r|\n|,/g);	//20170401: use tag name as value in "category", 20170417: allow parse with '\r' and ','
				vlist[tagname] = vl_tmp;
				leninfo.push(vlistinfo.min);
				leninfo.push(vlistinfo.max);
			}
		}
	} else if(type === "fulltext") {
		vlist = new VocabularyList();
		termlists = params.termlists;
		for(i = 0, li = termlists.length; i < li; i++){
			vlistinfo = vlist.addCategory(termlists[i]["name"], termlists[i]["contentcsv"], /\r\n|\r|\n|,/g);	// 20170417 can parse the list with '\r' and ','
			leninfo.push(vlistinfo.min);
			leninfo.push(vlistinfo.max);
		}
	}
	// Decide range of term length
	leninfo.sort();
	min = (leninfo.legnth !== 0 && min < leninfo[0]) ? leninfo[0] : min;
	max = (leninfo.length !== 0 && max > leninfo[leninfo.length - 1]) ? leninfo[leninfo.length - 1] : max;
	
	// This part will be changed in order to give message to main code(progress).
	var gs = (type === "xmltag") ? new GramSearcherXml() : new GramSearcher();
	var statresult = {"result-normal": [], "result-categorized": []};
	var documentresult = [];
	var vocabularyresult = [];
	var categorizeddocresult = [];
	var xmltagdetails = [];
	var extrametas = {};
	
	
	var i, li, j, lj, k, lk, p, lp;
	var doc, res, tmp_result;
	var idcatmap, idarrmap;
	var docres;
	
	if(type === "xmltag"){
		for(i = 0, li = doclist.length; i < li; i++){
			doc = doclist[i];
			res = gs.searchInXml(doc.xmltaggingdata || {}, params.xmltagginginfo, vlist);
			statresult["result-normal"].push(res["result-normal"]);
			statresult["result-categorized"].push(res["result-categorized"]);
			
			// Merge metadata
			extrametas = Object.assign(extrametas, doclist[i]["extrameta"]);
			
			postMessage(JSON.stringify({
				"msgtype": 0,
				"msg": ("Process: " + (i + 1) + "/" + doclist.length),
				"process": (i + 1) / doclist.length
			}));
		}
	} else if (type === "fulltext") {
		for(i = 0, li = doclist.length; i < li; i++){
			doc = doclist[i];
			res = gs.searchGram(doc.text, "。", vlist, min, max);
			statresult["result-normal"].push(res["result-normal"]);
			statresult["result-categorized"].push(res["result-categorized"]);
			
			// Merge metadata
			extrametas = Object.assign(extrametas, doclist[i]["extrameta"]);
			
			postMessage(JSON.stringify({
				"msgtype": 0,
				"msg": ("Process: " + (i + 1) + "/" + doclist.length),
				"process": (i + 1) / doclist.length
			}));
		}
	}
	
	postMessage(JSON.stringify({
		"msgtype": 0,
		"msg": "Analysis Done. Saving Result...",
		"process": 1
	}));
	
	var wordclouddata_obj = {};
	var wordclouddata_arr = {};
	var corpusname, elem_word;
	
	for(i = 0, li = params.corpusnames.length; i < li; i++){
		wordclouddata_obj[params.corpusnames[i]] = {};
		wordclouddata_arr[params.corpusnames[i]] = [];
	}
	
	for(i = 0, li = statresult["result-normal"].length; i < li; i++){
		tmp_result = statresult["result-normal"][i];
		documentresult.push({
			"corpus": doclist[i]["corpus"],
			"filename": doclist[i]["filename"],
			"title": doclist[i]["title"],
			"source": doclist[i]["source"],
			"docclass": doclist[i]["docclass"],
			"order": doclist[i]["order"],
			"passageid": doclist[i]["passageid"],
			"extrameta": doclist[i]["extrameta"],
			"termscount": tmp_result.length,
			"totaloccur": 0,
			"wordlist": []
		});
		for(j = 0, lj = tmp_result.length; j < lj; j++){
			tmp_wordresult = tmp_result[j];
			documentresult[i]["totaloccur"] += tmp_wordresult["freq"];	// accumulate total occurence
			documentresult[i]["wordlist"].push({
				"category-id": (tmp_wordresult["category-id"] !== undefined) ? tmp_wordresult["category-id"] : undefined,
				"category-name": tmp_wordresult["category-name"],
				"word-id": (tmp_wordresult["wordid"] !== undefined) ? tmp_wordresult["wordid"] : undefined,
				"word": tmp_wordresult["word"],
				"freq": tmp_wordresult["freq"]
			});
			
			if(wordclouddata_obj[doclist[i]["corpus"]] === undefined){
				wordclouddata_obj[doclist[i]["corpus"]] = {};
			}
			if(wordclouddata_obj[doclist[i]["corpus"]][tmp_wordresult["word"]] === undefined){
				wordclouddata_obj[doclist[i]["corpus"]][tmp_wordresult["word"]] = 0;
			}
			wordclouddata_obj[doclist[i]["corpus"]][tmp_wordresult["word"]] += tmp_wordresult["freq"];
		}
	}
	
	for(corpusname in wordclouddata_obj){
		for(elem_word in wordclouddata_obj[corpusname]){
			wordclouddata_arr[corpusname].push({
				"text": elem_word,
				"weight": wordclouddata_obj[corpusname][elem_word],
				"html": { "title": elem_word + "\nTerm Freq: " + wordclouddata_obj[corpusname][elem_word] }
			});
		}
		wordclouddata_arr[corpusname] = wordclouddata_arr[corpusname].sort(function(a, b){
			return b.weight - a.weight;
		}).slice(0, 60);
	}
	
	wordclouddata_obj = {};	// release memory
	
	if(type === "fulltext"){
		idcatmap = vlist.getIDNamePair();
		idarrmap = vlist.getIdArridxMap();
				
		// Categorized Document List
		for(i = 0, li = idcatmap.length; i < li; i++){
			idcatpair = idcatmap[i];
			categorizeddocresult.push({
				"category-id": idcatpair["id"],
				"category-name": idcatpair["name"],
				"document-list": []
			});
		}
		
		for(i = 0, li = statresult["result-categorized"].length; i < li; i++){
			docres = statresult["result-categorized"][i];
			for(j = 0, lj = docres.length; j < lj; j++){
				// Distribute the file's result to each occured category
				var catlist = docres[j];
				var targetidx = idarrmap[catlist["category-id"]];
				var targetlist = categorizeddocresult[targetidx]["document-list"];
				targetlist.push({
					"corpus": doclist[i]["corpus"],
					"filename": doclist[i]["filename"],
					"title": doclist[i]["title"],
					"source": doclist[i]["source"],
					"docclass": doclist[i]["docclass"],
					"order": doclist[i]["order"],
					"passageid": doclist[i]["passageid"],
					"extrameta": doclist[i]["extrameta"],
					"termscount": 0,
					"totaloccur": 0,
					"termlist": [],
					"detail": []
				});
				var targetres = targetlist[targetlist.length - 1];
				for(var k = 0; k < catlist["word-list"].length; k++){
					// Add result
					var wordres = catlist["word-list"][k];
					targetres["termscount"] += 1;
					targetres["totaloccur"] += wordres["freq"];
					targetres["termlist"].push(wordres["word"]);
					targetres["detail"].push(wordres["word"] + "(" + wordres["freq"] + ")");
				}
			}
		}
		
		// Form result for all volcabulary, in all category
		for(i = 0, li = idcatmap.length; i < li; i++){
			var idcatpair = idcatmap[i];
			vocabularyresult.push({
				"category-id": idcatpair["id"],
				"category-name": idcatpair["name"],
				"category-list": []
			});
			var categorywords = vlist.getCategoryListById(idcatpair["id"]);
			for(var j = 0; j < categorywords.length; j++){
				vocabularyresult[i]["category-list"].push({
					"word-id": j,
					"word": categorywords[j],
					"df": 0,
					"tf": 0
				});
			}
		}
			
		// Fill in df and tf information based on 'documentresult'
		for(var i = 0; i < documentresult.length; i++){
			var tmpwordlist = documentresult[i]["wordlist"];
			for(var j = 0; j < tmpwordlist.length; j++){
				var tmpwordresult = tmpwordlist[j];
				var targetcatarridx = idarrmap[tmpwordresult["category-id"]];
				var targetwordid = tmpwordresult["word-id"];
				var targetvocresult = vocabularyresult[targetcatarridx]["category-list"][targetwordid];
				targetvocresult["df"] += 1;
				targetvocresult["tf"] += tmpwordresult["freq"];
			}
		}
			
		// Sort by tf and release items with no occurencce
		for(var i = 0; i < vocabularyresult.length; i++){
			var targetlist = vocabularyresult[i]["category-list"];
			targetlist.sort(function(a, b){return b.tf - a.tf;});
			// Dispose words without occurence
			for(var j = 0; j < targetlist.length; j++){
				if(targetlist[j]["df"] === 0){	// If no df, then tf = 0
					targetlist.splice(j);
					break;
				}
			}
		}
	} else if (type === "xmltag") {
		var namearrmap = {};
		var vocabularyres_temp = {};
		
		
		for(i = 0, li = params.xmltagginginfo.tagnames.length; i < li; i++){
			categorizeddocresult.push({
				"category-name": params.xmltagginginfo.tagnames[i],
				"document-list": []
			});
			// vocabularyresult.push({
			//	"category-name": params.xmltagginginfo.tagnames[i];
			//	"category-list": []
			// });
			namearrmap[params.xmltagginginfo.tagnames[i]] = i;
		}
		
		for(i = 0, li = statresult["result-categorized"].length; i < li; i++){
			docres = statresult["result-categorized"][i];
			
			for(j = 0, lj = docres.length; j < lj; j++){
				catlist = docres[j];
				targetidx = namearrmap[catlist["category-name"]];				
				targetlist = categorizeddocresult[targetidx]["document-list"];

				targetlist.push({
					"filename": doclist[i]["filename"],
					"title": doclist[i]["title"],
					"source": doclist[i]["source"],
					"docclass": doclist[i]["docclass"],
					"order": doclist[i]["order"],
					"passageid": doclist[i]["passageid"],
					"extrameta": doclist[i]["extrameta"],
					"termscount": catlist["word-list"].length,	// 20170623 fix wrong value
					"totaloccur": 0,							// 20170623 fix wrong initial value
					"termlist": [],
					"detail": []
				});
				targetres = targetlist[targetlist.length - 1];
				
				if(vocabularyres_temp[catlist["category-name"]] === undefined){
					vocabularyres_temp[catlist["category-name"]] = {};
				}
				
				for(k = 0, lk = catlist["word-list"].length; k < lk; k++){
					wordres = catlist["word-list"][k];
					// targetres["termscount"] += 1; (removed) 20170412
					targetres["totaloccur"] += wordres["freq"];
					targetres["termlist"].push(wordres["word"]);
					targetres["detail"].push(wordres["word"] + "(" + wordres["freq"] + ")");
					
					if(vocabularyres_temp[catlist["category-name"]][wordres["word"]] === undefined){
						vocabularyres_temp[catlist["category-name"]][wordres["word"]] = { "word": wordres["word"], "df": 0, "tf": 0 };
					}
					vocabularyres_temp[catlist["category-name"]][wordres["word"]]["df"] += 1;
					vocabularyres_temp[catlist["category-name"]][wordres["word"]]["tf"] += wordres["freq"];
					
					// 20170412 Fill in xmldetail
					for(p = 0, lp = wordres["attrsinfo"].length; p < lp; p++){
						xmltagdetails.push({
							"filename": doclist[i]["filename"],
							"title": doclist[i]["title"],
							"source": doclist[i]["source"],
							"docclass": doclist[i]["docclass"],
							"order": doclist[i]["order"],
							"passageid": doclist[i]["passageid"],
							"extrameta": doclist[i]["extrameta"],
							"category-name": catlist["category-name"],
							"text": wordres["word"],
							"attr-details": JSON.stringify(wordres["attrsinfo"][p]["attrs"]).slice(1, -1),
							"freq": wordres["attrsinfo"][p]["freq"]
						});
					}
					
				}
			}
		}
		for(var resv_catname in vocabularyres_temp){
			var resv_cattermlist = vocabularyres_temp[resv_catname];
			vocabularyresult.push({
				"category-name": resv_catname,
				"category-list": []
			});
			var resv_targetlist = vocabularyresult[vocabularyresult.length - 1]["category-list"];
			for(var resv_termname in resv_cattermlist){
				var resv_termresult = resv_cattermlist[resv_termname];
				resv_targetlist.push({
					"word": resv_termresult["word"],
					"df": resv_termresult["df"],
					"tf": resv_termresult["tf"]
				});
			}
		}
		
		// Sort all lists by tf
		for(i = 0, li = vocabularyresult.length; i < li; i++){
			var targetlist = vocabularyresult[i]["category-list"];
			targetlist.sort(function(a, b){return b.tf - a.tf;});
		}
		
		// Form Word Cloud Information (by corpus?)
	}
	
	var date = new Date();
	var timetagstr = date.toISOString().substr(0, 10).replace(/-/g, "") + date.toTimeString().substr(0, 8).replace(/:/g, "") + ".csv";
	
	postMessage(JSON.stringify({
		"msgtype": 1,
		"result": {
			"documentresult": documentresult,
			"vocabularyresult": vocabularyresult,
			"categorizeddocumentresult": categorizeddocresult,
			"extrametas": Object.keys(extrametas),
			"xmltagdetails": xmltagdetails,	// 20170412
			"wordclouddata": wordclouddata_arr	// 20170424
		},
		"timetag": timetagstr
	}));
	return;
});