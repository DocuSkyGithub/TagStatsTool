var TermStat = new (function(){	
	// Loading modal control
	var startLoading = function(){
		$("#dialog-loading").dialog("open");
		return;
	}
	var stopLoading = function(elps){
		var elapse = (elps && elps >= 0) ? elps : 0;
		setTimeout(function(){
			$("#dialog-loading").dialog("close");
			return;
		}, elapse);
		return;
	}
	
	// String related
	var tohtmlstr = function(s){
		var str = (s !== undefined && typeof s === "string") ? s : (s === undefined || s === null) ? "" : s.toString();
		return $('<div/>').append(str).text();
	}
	
	// warning: not work in some cases (e.g.: "/n")
	var addquo = function(s, q, c){	// 20170412: Add option to fit CSV format requirement
		var str = (s !== undefined && typeof s === "string") ? s : (s === undefined || s === null) ? "" : s.toString();
		var quotemark = (typeof q === "string" && q) ? q : '"';
		var csv = (c === undefined) ? true : (c === true);
		str = (csv) ? str.replace(new RegExp(quotemark, "g"), quotemark + quotemark) : str;	// 20170412
		
		return quotemark + str + quotemark;
	};
	// TODO: TO CHECK WHICH KIND OF NODES SHOULD BE STRIPPED WHEN DOING TEXT PROCESSING IN XML.
	var xmltagandtextextract = function(s){
		return (typeof s === "string") ? s.replace(/<!(.*?)>|<\?(.*?)\?>/g , "") : "";	// remove comments, doctype declarations, and processing instructions.
	}
	
	/*
	var simpleIsEqualObject = function(a, b){
		var keys_a = Object.keys(a).sort(), keys_b = Object.keys(b).sort();
		if(keys_a.length === keys_b.length){
			return keys_a.every(function(elem, idx, arr){
				return (elem === keys_b[idx]) && (a[elem] === b[keys_b[idx]]);
			});
		}
		return false;
	}
	*/
	
	// 20170703: used to filter out HTML tags
	var htmltags = ["!DOCTYPE", "a", "abbr", "acronym", "address", "applet", "area", "article", "aside", "audio", "b", "base", "basefont", "bdi", "bdo", "big", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "command", "datalist", "dd", "del", "details", "dfn", "dir", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "font", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "map", "mark", "menu", "meta", "meter", "nav", "noframes", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"];
	
	// 20170322: Combine all information of taggings
	// 20170703: Allow search under multiple layers. Filter out HTML tags.
	var getxmltaggingdata = function(elem){
		var childnodes= [], childnode = {};
		var childtagnames = {};
		var i, li, j, lj, elem_attr, elem_key;
		var attr_tmp = {};
		var textcontent = "";
		var keystr = "";
		var keyarr = [];
		var result = { "tagnamelist": [], "taggings": {} };
		
		var stack = [elem.childNodes];
		
		while (stack.length !== 0){
			childnodes = stack.pop();
			if(childnodes !== undefined){
				for(i = 0, li = childnodes.length; i < li; i++){
					childnode = childnodes[i];
					if(childnode.nodeType === 1  && htmltags.indexOf(childnode.nodeName) < 0){
						attr_tmp = {};
						keystr = "";
						keyarr = [];
						textcontent = tohtmlstr(childnode.innerHTML).trim();	// 20170413 use trim() to remove noise blanks and newlines
						keystr = keystr + textcontent + "\t";
						for(j = 0, lj = childnode.attributes.length; j < lj; j++){
							elem_attr = childnode.attributes[j];
							attr_tmp[elem_attr.name] = elem_attr.value;
							keyarr.push(elem_attr.name);
						}
						keyarr.sort();
						for(j = 0, lj = keyarr.length; j < lj; j++){
							elem_key = keyarr[j];
							keystr = keystr + elem_key + '="' + attr_tmp[elem_key] + '"\t';
						}
						
						if(!result.taggings[childnode.nodeName]){
							result.taggings[childnode.nodeName] = {};
						}
						if(!result.taggings[childnode.nodeName][keystr]){
							result.taggings[childnode.nodeName][keystr] = { "freq": 0, "text": textcontent, "attrs": attr_tmp };
						}
						result.taggings[childnode.nodeName][keystr].freq += 1;
						if(childnode.hasChildNodes()){
							stack.push(childnode.childNodes);
						}
					}
				}
			}
		}
		result.tagnamelist = Object.keys(result.taggings).sort();
		return result;
	}
	
	// Screen update
	var updateCorpus = function(){
		var htmlstr = "";
		var i, li;
		
		var cnum = savedlist_corpus.length;
		
		if(savedlist_corpus.length === 0){
			htmlstr = '<tr class="termstat-tr">' +
						'<th class="termstat-th">No saved corpus exist.</th>' +
						'</tr>';
		} else {
			htmlstr = '<tr class="termstat-tr">' +
						'<th class="termstat-th">ID</th>' +
						'<th class="termstat-th">Title</th>' +
						'<th class="termstat-th">#Doc</th>' +
						'<th class="termstat-th">Del</th>' +
						'</tr>';
		}
		
		for(i = 0, li = savedlist_corpus.length; i < li; i++){
			htmlstr = htmlstr +
				'<tr class="termstat-tr">' +
				'<td class="termstat-td centertext">' + (i+1) + '</td>' +
				'<td class="termstat-td">' + savedlist_corpus[i].name + '</td>' +
				'<td class="termstat-td centertext">' + savedlist_corpus[i].num + '</td>' +
				'<td class="termstat-td">' + '<button type="button" class="btn-delete deletecorpus">❌</button>' + '</td>' +
				'</tr>';
		}
		
		$("#savedcorpuslist").html(htmlstr);
		$(".deletecorpus").each(function(idx, elem){
			$(this).click(function(e){
				savedlist_corpus.splice(idx, 1);
				updateCorpus();
				updatePreview();
				return;
			});
		});
		
		$("#counter-corpus").text((cnum > 99) ? "99+" : cnum.toString());
		
		return;
	};
	
	var updateTermList = function(){
		var htmlstr = "";
		var i, li;
		
		var tlnum = savedlist_termlist.length;
		
		if(tlnum === 0){
			htmlstr = '<tr class="termstat-tr">' +
						'<th class="termstat-th">No saved term list exist.</th>' +
						'</tr>';
		} else {
			htmlstr = '<tr class="termstat-tr">' +
						'<th class="termstat-th">ID</th>' +
						'<th class="termstat-th">Category Name</th>' +
						'<th class="termstat-th">View</th>' +
						'<th class="termstat-th">Del</th>' +
						'</tr>';
		}
		
		for(i = 0, li = savedlist_termlist.length; i < li; i++){
			htmlstr = htmlstr +
				'<tr class="termstat-tr">' +
				'<td class="termstat-td centertext">' + (i+1) + '</td>' +
				'<td class="termstat-td">' + savedlist_termlist[i].name + '</td>' +
				'<td class="termstat-td">' + '<button type="button" class="btn-view viewtermlist">▶</button>' + '</td>' +
				'<td class="termstat-td">' + '<button type="button" class="btn-delete deletetermlist">❌</button>' + '</td>' +
				'</tr>';
		}
		
		$("#savedtermlist").html(htmlstr);
		$(".deletetermlist").each(function(idx, elem){
			$(this).click(function(e){
				savedlist_termlist.splice(idx, 1);
				updateTermList();
				updatePreview();
				return;
			});
		});
		$(".viewtermlist").each(function(idx, elem){
			$(this).click(function(e){
				$("#dialog-termlist").html(savedlist_termlist[idx].contentcsv.replace(/\r\n|\r|\n|,/g, "<br/>"));
				$("#dialog-termlist").dialog("option", "title", "Term List - " + savedlist_termlist[idx].name).dialog("open");
				return;
			});
		});
		
		$("#counter-termlist").text((tlnum > 99) ? "99+" : tlnum.toString());
		
		return;
	};
	
	var updatePreview = function(){
		var htmlstr = "";
		var xmltaglist = [];
		var i, li, j, lj;
		var tagname = "";
		
		// Update corpus and term list tables.
		if(savedlist_corpus.length === 0){
			htmlstr = '<tr><th>No corpus exist.</th></tr>';
		} else {
			htmlstr = "<tr><th>Corpora (" + savedlist_corpus.length + ")</th></tr>";
			for(i = 0, li = savedlist_corpus.length; i < li; i++){
				htmlstr = htmlstr + "<tr><td>" +  savedlist_corpus[i].name + "</td></tr>";
				// Update xml info
				if(savedlist_corpus[i].xmltaglist !== undefined){
					xmltaglist = arrmerge(xmltaglist, savedlist_corpus[i].xmltaglist);
				}
			}
		}
		$("#analysispreview-ft-corpuslist").empty().append(htmlstr);
		$("#analysispreview-xt-corpuslist").empty().append(htmlstr);
		
		htmlstr = "";
		if(savedlist_termlist.length === 0){
			htmlstr = '<tr><th>No term list exist.</th></tr>';
		} else {
			htmlstr = "<tr><th>Term Lists (" + savedlist_termlist.length + ")</th></tr>";
			for(i = 0, li = savedlist_termlist.length; i < li; i++){
				htmlstr = htmlstr + "<tr><td>" +  savedlist_termlist[i].name + "</td></tr>";
			}
		}
		$("#analysispreview-ft-termlist").empty().append(htmlstr);
		
		// Update xml tags
		if(xmltaglist.length !== 0){
			htmlstr = "<tr><th></th><th>Tag Name</th><th>Filtering Term List</th></tr>"
			for(i = 0, li = xmltaglist.length; i < li; i++){
				tagname = xmltaglist[i];
				htmlstr = htmlstr +
					'<tr>' +
						'<td class="align-center"><div class="cbox">' +
							'<input type="checkbox" class="termstat-preview-cbox-selecttag" value="' + tagname + '" id="termstat-xmltag-' + tagname + '" checked="true"/>' +
							'<label for="termstat-xmltag-' + tagname + '"></label>' +
						'</div></td>' +
						'<td>' + tagname + '</td>' +
						'<td class="align-center">' +
							'<select class="termstat-preview-select-filter" name="termstat-xmltag-' + tagname + '-select">' +
							'<option value="none">No Filtering</option>';
				for(j = 0, lj = savedlist_termlist.length; j < lj; j++){
					htmlstr = htmlstr + '<option value="' + j + '">' + savedlist_termlist[j].name + '</option>';
				}
			}
			htmlstr = htmlstr + '</select></td></tr>';
		} else {
			htmlstr = "<tr><th>No XML tag exist in current corpus.</th></tr>";
		}
		$("#analysispreview-xt-taglist").empty().append(htmlstr).find(".termstat-preview-cbox-selecttag").
			each(function(idx, elem){
				$(this).on("change", function(e){
					// Enable or disable select
					$("#analysispreview-xt-taglist .termstat-preview-select-filter").eq(idx).attr("disabled", !$(this).is(":checked"));
					return;
				});
				return;
			});
		
		//	$("#runanalysis").attr("disabled", (savedlist_corpus.length === 0 || savedlist_termlist.length === 0)); // 20170329
		$("#analysis-run-fulltext").attr("disabled", (savedlist_corpus.length === 0 || savedlist_termlist.length === 0));
		$("#analysis-run-xmltag").attr("disabled", (savedlist_corpus.length === 0));
		return;
	};
	
	// DocuSky functions handler
	// 20170424: Add corpus metadata
	var handler_DocuSkyDocPage = function(){
		var filename = "", title = "", source = "", docclass = "", order = "", textstr = "", corpusname = "";
		var extrametaxml = {};
		var extrametaobj = {};
		var textxml = {}, paragraphs = [], tagnames = [], contentxml= {};
		var parser = new DOMParser();
		var i, j, li, lj, k, lk;
		var tmpdoc, exmeta;
		
		for(i = 0, li = docuSkyObj_doc.docList.length; i < li; i++){
			tmpdoc = docuSkyObj_doc.docList[i].docInfo;
			corpusname = docuSkyObj_doc.db + "/" + docuSkyObj_doc.corpus;
			filename = tohtmlstr(tmpdoc.docFilename);
			title = tohtmlstr(tmpdoc.docTitleXml);
			source = tohtmlstr(tmpdoc.docCompilation);
			docclass = tohtmlstr(tmpdoc.docClass);
			order = tohtmlstr(tmpdoc.docCompilationVol);
			textstr = tmpdoc.docContentXml;
			
			// 20161026: Extract extra metadata
			extrametaobj = {};
			// 20170214: if DOMParser will cause error when giving undefined as input
			extrametaxml = (tmpdoc.docMetadataXml !== undefined) ? parser.parseFromString(tmpdoc.docMetadataXml, "text/xml").children[0] : undefined;
			if(extrametaxml && extrametaxml.tagName === "DocMetadata"){
				extrametaxml = extrametaxml.children;
				for(j = 0, lj = extrametaxml.length; j < lj; j++){
					exmeta = extrametaxml[j];
					extrametaobj[exmeta.tagName] = exmeta.textContent;
				}
			}
			
			// Try to parse text xml, and split contents in <Passage> if tag exists. If error happens, only extract text nodes out.
			textxml = parser.parseFromString(textstr, "text/xml");
			
			if( textxml.getElementsByTagName("parsererror").length === 0 ){
				paragraphs = textxml.querySelectorAll("Content>Paragraph");	//20170317
				if( paragraphs.length !== 0 ){
					for(j = 0, lj = paragraphs.length; j < lj; j++){
						xmltaggingdata = getxmltaggingdata(paragraphs[j]);
						tempdspages_corpus.push({
							"corpus": corpusname,
							"filename": filename,
							"title": title,
							"source": source,
							"docclass": docclass,
							"order": order,
							"passageid": "" + (j + 1),
							"extrameta": extrametaobj,
							"xmltext": xmltagandtextextract("<Content>" + paragraphs[j].innerHTML + "</Content>"),
							"text": tohtmlstr(paragraphs[j].innerHTML),
							"xmltaggingdata": xmltaggingdata
						});
					}
				} else {
					contentxml = undefined;
					for(j = 0, lj = textxml.childNodes.length; j < lj; j++){
						if(textxml.childNodes[j].nodeType === 1 && textxml.childNodes[j].nodeName === "Content"){
							contentxml = textxml.childNodes[j];
							break;
						}
					}
					tempdspages_corpus.push({
						"corpus": corpusname,
						"filename": filename,
						"title": title,
						"source": source,
						"docclass": docclass,
						"order": order,
						"passageid": "",
						"extrameta": extrametaobj,
						"xmltext": (contentxml !== undefined) ? xmltagandtextextract(contentxml.outerHTML) : undefined,
						"text": (contentxml !== undefined) ? tohtmlstr(contentxml.innerHTML) : textstr	//20170321 If cannot find <Content> tag, use pure text as content
					});
				}
			} else {	// Basically it won't happen
				text = tohtmlstr(text);
				tempdspages_corpus.push({
					"corpus": corpusname,
					"filename": filename,
					"title": title,
					"source": source,
					"docclass": docclass,
					"order": order,
					"passageid": "",
					"extrameta": extrametaobj,
					"text": textstr
				});
			}
		}
		return;
	};
	
	var handler_DocuSkyDocDone = function(){
		var i, li;
		var taglist = [];
		
		for(i = 0, li = tempdspages_corpus.length; i < li; i++){
			if(tempdspages_corpus[i].xmltaggingdata !== undefined){
				taglist = arrmerge(taglist, tempdspages_corpus[i].xmltaggingdata.tagnamelist);
			}
		}
		
		savedlist_corpus.push( { "name": docuSkyObj_doc.db + "/" + docuSkyObj_doc.corpus, "num": tempdspages_corpus.length, "docs": tempdspages_corpus, "xmltaglist": taglist } );
		tempdspages_corpus = [];
		updateCorpus();
		updatePreview();		
		return;
	};
	
	var docuSkyDocPageIterator = function(tgt, db, cps, cp, ps, pt, evt, minps, maxelps, tcb, pcb, flag){
		var timetag = new Date().getTime();
		var elapse = (timetag - pt) / 1000;
		var currentpage = cp;
		var nextpage = 0;
		var psize = ps;
		var minsize = (Number.isInteger(minps) && minps > 0) ? minps : 10;
		var maxelapse = (maxelps > 2) ? maxelps : 2; // seconds
		var maxpage = Math.ceil(docuSkyObj_doc.totalFound / psize);
		// The number may be wrong when retrieving the last page, but under this situation it will not be used.
		var pageobtained = psize * currentpage;
		var totalcallback = (typeof tcb === "function") ? tcb : function(){return;};
		var pagecallback = (typeof pcb === "function") ? pcb : function(){return;};
		
		// Handle obtained page
		pagecallback();
		
		if(currentpage === maxpage || maxpage === 0){	// (maxpage === 0) : in case user choosing an empty corpus
			// The whole corpus is obtained
			totalcallback();
		} else {
			// If current time is less than maxelapse, check if we can double the magnitude
			if(elapse <= maxelapse){
				if(pageobtained % (psize * 2) === 0){
					psize = psize * 2;
					nextpage = (pageobtained / psize) + 1;
				} else {
					nextpage = currentpage + 1;
				}
			} else if (elapse <= maxelapse * 1.25){ // Else, if current time is less than (1.25 * maxelapse), maintain current magnitude
				nextpage = currentpage + 1;
			} else { // If current time is more than 1.25 * maxelapse, try lower the magnitude to half
				if(psize > minsize && psize % minsize === 0){
					psize = psize / 2;
					nextpage = (pageobtained / psize) + 1;
				} else {
					nextpage = currentpage + 1;
				}
			}
			timetag = new Date().getTime();
			docuSkyObj_doc.getDbCorpusDocumentsGivenPageAndSize(tgt, db, cps, nextpage, psize, evt, function(){
				docuSkyDocPageIterator(tgt, db, cps, nextpage, psize, timetag, evt, minsize, maxelapse, totalcallback, pagecallback);
			}, (pageobtained + "/" + docuSkyObj_doc.totalFound));
		}
		return;
	};
	
	var tempfile_corpus = [];
	var tempfile_termlist = [];
	var tempdspages_corpus = [];
	var savedlist_corpus = [];
	var savedlist_termlist = [];
	var result = {};
	var timetag = "";
	
	this.loadCorpusFiles = function(){
		tempfile_corpus = [];
		var files = document.getElementById("addcorpus-clientfile-textfiles").files;
		var mtr = new MultiFileReader();
		var i, li;
		var fl, fd;
		
		if(files.length === 0){
			return;
		}
		for(i = 0, li = files.length; i < li; i++){
			fl = files[i];
			if(!fl.type || fl.type !== "text/plain"){
				alert('File "' + fl.name + '" is not pure text file. Please make sure all selected files are in pure text format.');
				$("#addcorpus-clientfile-textfiles").val("").trigger("change");
				return;
			}
		}
		
		startLoading();
		
		// 20170323: TODO: TRY HANDLING XML CONTENT HERE
		mtr.readFiles(files, "text",
			[function(data){
				for(i = 0, li = data.length; i < li; i++){
					// NOTE: Temporary form
					var fd = data[i];
					tempfile_corpus.push({
						"filename": fd.name,
						"title": "",
						"source": "",
						"docclass": "",
						"order": (i + 1).toString(),
						"passageid": "",
						"extrameta": {},
						"xmltext": undefined,
						"text": fd.content
					});
				}
				stopLoading(400);
				return;
			}],
			[function(data){
				stopLoading(400);
				alert('Error happens when reading file "' + data.name + '".\nError: ' + data.content.name + "\nMessage: " + data.content.message);
				return;
			}]
		);
		return;
	};
	
	this.newCorpusByFiles = function(){
		var name = $("#addcorpus-clientfile-corpusname").val().trim();
		var i, li;
		if(!name.length){	// empty string
			alert("Please enter in corpus name.");
			return;
		}
		if(tempfile_corpus.length === 0){
			alert("Have not select any file for corpus document. Please select at least one file in pure text format.");
			return;
		}
		
		startLoading();
		for(i = 0, li = tempfile_corpus.length; i < li; i++){
			tempfile_corpus[i].corpus = name;	// 20170424
			tempfile_corpus[i].title = name;
			tempfile_corpus[i].source = name;
		}
		savedlist_corpus.push({ "name": name, "num": tempfile_corpus.length, "docs": tempfile_corpus });
		$("#addcorpus-clientfile-corpusname").val("");
		$("#addcorpus-clientfile-textfiles").val("").trigger("change");
		tempfile_corpus = [];
		updateCorpus();
		updatePreview();
		stopLoading(400);
		return;
	};
	
	this.loadTermListFiles = function(){
		tempfile_termlist = [];
		var files = document.getElementById("addtermlist-clientfile-textfiles").files;
		var mfr = new MultiFileReader();
		var subidx;
		var i, li;
		var fd;
		var cname = "";
		
		if(files.length === 0){
			return;
		}
		
		startLoading();
		mfr.readFiles(files, "text",
			[function(data){
				for(i = 0, li = data.length; i < li; i++){
					var fd = data[i];
					subidx = fd.name.search(/\.[^\.]+$/g);      // 20170709: Tu removes 'u' modifier
					cname = fd.name.substring(0, (subidx > 0) ? subidx : undefined);
					tempfile_termlist.push({"name": cname, "contentcsv": fd.content});
				}
				stopLoading(400);
				return;
			}],
			[function(data){
				stopLoading(400);
				alert('Error happens when reading file"' + data.name + '".\nError: ' + data.content.name + "\nMessage: " + data.content.message);
				return;
			}]
		);
		return;
	};
	
	this.newTermListByFiles = function(){
		var files = tempfile_termlist;
		if(files.length === 0){
			alert("Have not select any file. Please select at least one file in pure text format.");
			return;
		}
		
		savedlist_termlist = savedlist_termlist.concat(tempfile_termlist);
		$("#addtermlist-clientfile-textfiles").val("").trigger("change");
		updateTermList();
		updatePreview();
		stopLoading(400);
		return;
	};
	

	this.docuSkyElasticPageGetter = function(tgt, db, cps, cp, ps, evt, minps, maxelps){
		var time = new Date().getTime();
		docuSkyObj_doc.getDbCorpusDocumentsGivenPageAndSize(tgt, db, cps, cp, ps, evt, function(){
			docuSkyDocPageIterator(tgt, db, cps, cp, ps, time, evt, minps, maxelps, handler_DocuSkyDocDone, handler_DocuSkyDocPage);
		}, "0/" + docuSkyObj_doc.totalFound);
		return;
	};
	
	this.docuSkyTermListCsvGetter = function(){
		var dsflist = docuSkyObj_file.categoryFilenameList;
		var dscategory = "DocuTools";
		var path = "TermStat/TermList/";
		var termlistcategories = {};
		var i, li;
		var fullpath = "", pathnames = [], catname = "", filename = "";
		var keys = [];
		var htmlstr = "", catname = "", catfiles = [];
		
		for(i = 0, li = dsflist[dscategory].length; i < li; i++){
			fullpath = dsflist[dscategory][i];
			// only allow format in: "(category name)/(json filename)"
			pathnames = fullpath.match(path + "(.*)")[1].split("/");
			if(pathnames.length === 2 && pathnames.every(function(i){return i;})){	// Notice: every() is not supported before IE9.
				catname = pathnames[0];
				filename = pathnames[1];
				if(!termlistcategories[catname]){
					termlistcategories[catname] = [];
				}
				termlistcategories[catname].push(filename);
			}
		}
		keys = Object.keys(termlistcategories);
		
		if(keys.length === 0){
			htmlstr = '<tr class="termstat-tr">' + 
						'<th class="termstat-th">No saved term list exist.</th>' +
					  '</tr>';
		} else {
			htmlstr = '<tr class="termstat-tr">' + 
				 '<th class="termstat-th">ID</th>' +
				 '<th class="termstat-th">Group Name</th>' +
				 '<th class="termstat-th">#List</th>' +
				 '<th class="termstat-th">Add</th>' +
			'</tr>';
		}
		
		for(i = 0, li = keys.length; i < li; i++){
			catname = keys[i];
			catfiles = termlistcategories[catname];
			htmlstr = htmlstr +
						'<tr class="termstat-tr">' +
							'<td class="termstat-td centertext">' + (i + 1) + '</td>' +
							'<td class="termstat-td">' + catname + '</td>' +
							'<td class="termstat-td centertext">' + catfiles.length + '</td>' +
							'<td class="termstat-td">' + '<button type="button" class="btn-add addtermlist-docusky-addtl">➕</button>' + '</td>' +
						'</tr>';
		}
		$("#addtermlist-docusky-tltable").empty().append(htmlstr);
		$(".addtermlist-docusky-addtl").each(function(idx){
			$(this).click(function(e){
				startLoading();
				// Need to be checked again...
				var catname = keys[idx];
				var filenames = termlistcategories[catname];
				var c = dscategory;
				var p = path + catname;
				var data = [];
				var i, li, item;
				
				var cb_s = function(data){
					for(i = 0, li = data.files.length; i < li; i++){
						item = data.files[i].content;
						savedlist_termlist.push({"name": item.name, "contentcsv": item.csv});
					}
					updateTermList();
					updatePreview();
					stopLoading(400);
					return;
				}
				var cb_f = function(data){
					alert("Error Code: " + data.code + "\nMessage:" + data.message);
					stopLoading(400);
					return;
				}
				
				for(i = 0, li = filenames.length; i < li; i++){
					data.push({
						"category": c,
						"datapath": p,
						"filename": filenames[i]
					});
				}
				DSMultiFileRetrieve(docuSkyObj_file, data, [cb_s], [cb_f]);
			});
		});
		return;
	}
	
	/* 20170420 deprecated
	this.selectAllCorpus = function(s){
		var select = (s === undefined) ? true : s;
		$("#analysis-choosecorpus input[type='checkbox']").each(function(idx, elem){
			$(this).prop("checked", select);
		});
		return;
	};
	
	this.selectAllTermList = function(s){
		var select = (s === undefined) ? true : s;
		$("#analysis-choosetermlist input[type='checkbox']").each(function(idx, elem){
			$(this).prop("checked", select);
		});
		return;
	};
	*/
	
	/*
	this.searchInTags = function(){
		var i, li;
		var corpusids = [], testdocuments = [], taglist = [];
		
		$("#analysis-choosecorpus input[type='checkbox']:checked").each(function(idx, elem){
			corpusids.push($(this).val());
		});

		if($("#searchintags").is(":checked")){
			for(i = 0, li = corpusids.length; i < li; i++){
				testdocuments = testdocuments.concat(savedlist_corpus[corpusids[i]].docs);
			}
			for(i = 0, li = testdocuments.length; i < li; i++){
				taglist = arrmerge(taglist, (testdocuments[i].tagnames || []));
			}
			console.log(taglist.join(", "));
		} else {
			
		}
		return;
	};
	*/
	/*
	var analysisPreview_FullText = function(){
		var corpusids = [], termlistids = [];
		var testdocuments = [], testtermlists = [], corpusnames = [];;
		var htmlstr = "";
		var i, li;
		
		// Check if available
		$("#analysis-choosecorpus input[type='checkbox']:checked").each(function(idx, elem){
			corpusids.push($(this).val());
		});
		$("#analysis-choosetermlist input[type='checkbox']:checked").each(function(idx, elem){
			termlistids.push($(this).val());
		});
		
		if(corpusids.length === 0){
			$("#analysispreview-ft-corpuslist").empty().append("<tr><th>No selected corpus.</th></tr>");
		} else {
			htmlstr = "<tr><th>Selected Corpora</th></tr>";
			for(i = 0, li = corpusids.length; i < li; i++){
				
				corpusnames.push(savedlist_corpus[corpusids[i]].name);
			}
			$("#analysispreview-ft-corpuslist").empty().append(htmlstr);
		}
		
		if(termlistids.length === 0){
			$("#analysispreview-ft-termlist").empty().append("<tr><th>No selected term list.</th></tr>");
		} else {
			htmlstr = "<tr><th>Selected Term Lists</th></tr>";
			for(i = 0, li = termlistids.length; i < li; i++){
				htmlstr = htmlstr + "<tr><td>" +  savedlist_termlist[termlistids[i]].name + "</td></tr>";
			}
			$("#analysispreview-ft-termlist").empty().append(htmlstr);
		}
		
		if(corpusids.length === 0 || termlistids.length === 0){
			$("#analysis-run-fulltext").attr("disabled", "disabled");
		} else {
			$("#analysis-run-fulltext").removeAttr("disabled").off("click").on("click", function(e){
				$("#dialog-analysispreview").dialog("close");
				for(i = 0, li = corpusids.length; i < li; i++){
					testdocuments = testdocuments.concat(savedlist_corpus[corpusids[i]].docs);
				}
				for(i = 0, li = termlistids.length; i < li; i++){
					testtermlists.push(savedlist_termlist[termlistids[i]]);
				}
				runAnalysis({"type": "fulltext", "docs": testdocuments, "termlists": testtermlists, "corpusnames": corpusnames});
				return;
			});
		}
		
		$("#termstat-analysispreview-xmltag").hide();
		$("#termstat-analysispreview-fulltext").show();
		$("#dialog-analysispreview").dialog("open");
		
		return;
	}
	
	var analysisPreview_XmlTag = function(){
		var corpusids = [];
		var corpusnames = [];
		var testdocuments = [];
		var xmltaglist = [];
		var htmlstr = "";
		var i, li, j, lj;
		var tagname = "";
		
		$("#analysis-choosecorpus input[type='checkbox']:checked").each(function(idx, elem){
			corpusids.push($(this).val());
		});

		for(i = 0, li = corpusids.length; i < li; i++){
			if(savedlist_corpus[corpusids[i]].xmltaglist !== undefined){
				xmltaglist = arrmerge(xmltaglist, savedlist_corpus[corpusids[i]].xmltaglist);
			}
		}
		
		if(corpusids.length === 0){
			$("#analysispreview-xt-corpuslist").empty().append("<tr><th>No selected corpus.</th></tr>");
		} else {
			htmlstr = "<tr><th>Selected Corpora</th></tr>";
			for(i = 0, li = corpusids.length; i < li; i++){
				htmlstr = htmlstr + "<tr><td>" +  savedlist_corpus[corpusids[i]].name + "</td></tr>";
				corpusnames.push(savedlist_corpus[corpusids[i]].name);
			}
			$("#analysispreview-xt-corpuslist").empty().append(htmlstr);
		}
		
		htmlstr = "";
		if(xmltaglist.length !== 0){
			htmlstr = "<tr><th></th><th>Tag Name</th><th>Filtering Term List</th></tr>"
			for(i = 0, li = xmltaglist.length; i < li; i++){
				tagname = xmltaglist[i];
				htmlstr = htmlstr +
					'<tr>' +
						'<td class="align-center"><div class="cbox">' +
							'<input type="checkbox" class="termstat-preview-cbox-selecttag" value="' + tagname + '" id="termstat-xmltag-' + tagname + '"/>' +
							'<label for="termstat-xmltag-' + tagname + '"></label>' +
						'</div></td>' +
						'<td>' + tagname + '</td>' +
						'<td class="align-center">' +
							'<select class="termstat-preview-select-filter" name="termstat-xmltag-' + tagname + '-select" disabled="disabled">' +
							'<option value="none">No Filtering</option>';
				for(j = 0, lj = savedlist_termlist.length; j < lj; j++){
					htmlstr = htmlstr + '<option value="' + j + '">' + savedlist_termlist[j].name + '</option>';
				}
				htmlstr = htmlstr + '</select></td></tr>';
			}
		} else {
			htmlstr = "<tr><th>No XML tag exist.</th></tr>";
		}
		
		$("#analysispreview-xt-taglist").empty().append(htmlstr).find(".termstat-preview-cbox-selecttag").
			each(function(idx, elem){
				$(this).on("change", function(e){
					// Enable or disable select
					$("#analysispreview-xt-taglist .termstat-preview-select-filter").eq(idx).attr("disabled", !$(this).is(":checked"));
					return;
				});
				return;
			});
		
		
		
		if(corpusids.length === 0 || xmltaglist.length === 0){
			$("#analysis-run-xmltag").off("click").attr("disabled", "disabled");
		} else {
			$("#analysis-run-xmltag").removeAttr("disabled").off("click").on("click", function(e){
				var selected_tagnames = [], filterlistmap = {}, filterlist = {};
				var filtergroup = $("#analysispreview-xt-taglist .termstat-preview-select-filter");
				var selectedtagname = "", filterlistid = "";
				var selectedtermlist = {};

				$("#analysispreview-xt-taglist").
					find(".termstat-preview-cbox-selecttag").each(function(idx, elem){
						if($(this).is(":checked")){
							selectedtagname = $(this).val();
							selected_tagnames.push(selectedtagname);
							filterlistid = filtergroup.eq(idx).children("option").filter(":selected").val();
							if(filterlistid !== "none"){
								selectedtermlist = savedlist_termlist[parseInt(filterlistid)];
								filterlistmap[selectedtagname] = selectedtermlist.name;
								filterlist[selectedtermlist.name] = selectedtermlist.contentcsv;
							} else {
								filterlistmap[selectedtagname] = undefined;
							}
						}
						return;
					});
				
				for(i = 0, li = corpusids.length; i < li; i++){
					testdocuments = testdocuments.concat(savedlist_corpus[corpusids[i]].docs);
				}

				$("#dialog-analysispreview").dialog("close");
				runAnalysis({"type": "xmltag", "docs": testdocuments, "xmltagginginfo": { "tagnames": selected_tagnames, "filtermap": filterlistmap, "filterlist": filterlist }, "corpusnames": corpusnames});
				return;
			});
		}
		
		$("#termstat-analysispreview-fulltext").hide();
		$("#termstat-analysispreview-xmltag").show();
		$("#dialog-analysispreview").dialog("open");
		return;
	}
	*/
	/* 20170420 deprecated
	this.analysisPreview = function(){
		var searchinxmltags = $("input#searchintags").is(":checked");
		if(searchinxmltags){
			analysisPreview_XmlTag();
		} else {
			analysisPreview_FullText();
		}
		return;
	}
	*/
	
	this.runAnalysis = function(type){
		var params = {}, docs = [], termlists = [], corpusnames = [];
		var selected_tagnames = [], filterlistmap = {}, filterlist = {};
		var selectedtagname = "", filterlistid = "", selectedtermlist = {};
		var i, li;
		var filtergroup = $("#analysispreview-xt-taglist .termstat-preview-select-filter");
		
		switch(type){
			case "text":
				for(i = 0, li = savedlist_corpus.length; i < li; i++){
					docs = docs.concat(savedlist_corpus[i].docs);
					corpusnames.push(savedlist_corpus[i].name);
				}
				for(i = 0, li = savedlist_termlist.length; i < li; i++){
					termlists.push(savedlist_termlist[i]);
				}
				runAnalysis_FullText({
					"type": "fulltext",
					"docs": docs,
					"termlists": termlists,
					"corpusnames": corpusnames
				});
				break;
			case "xml":
				for(i = 0, li = savedlist_corpus.length; i < li; i++){
					docs = docs.concat(savedlist_corpus[i].docs);
					corpusnames.push(savedlist_corpus[i].name);
				}
				$("#analysispreview-xt-taglist").
					find(".termstat-preview-cbox-selecttag").each(function(idx, elem){
						if($(this).is(":checked")){
							selectedtagname = $(this).val();
							selected_tagnames.push(selectedtagname);
							filterlistid = filtergroup.eq(idx).children("option").filter(":selected").val();
							if(filterlistid !== "none"){
								selectedtermlist = savedlist_termlist[parseInt(filterlistid)];
								filterlistmap[selectedtagname] = selectedtermlist.name;
								filterlist[selectedtermlist.name] = selectedtermlist.contentcsv;
							} else {
								filterlistmap[selectedtagname] = undefined;
							}
						}
						return;
					});
				runAnalysis_XmlTag({
					"type": "xmltag",
					"docs": docs,
					"xmltagginginfo": { "tagnames": selected_tagnames, "filtermap": filterlistmap, "filterlist": filterlist },
					"corpusnames": corpusnames
				});
				break;
			default:
				break;
		}
		return;
	}
	
	var runAnalysis_FullText = function(params){
		var myworker = new Worker("./js/worker_search.js");
		var timer = new Stopwatch(), elapseID = 0;
		
		$("#processbar-ratio").css("width", "0%");
		$("#processbar").show();
		startLoading();
		
		timer.start();
		elapseID = setInterval(function(){
			var t = timer.getTime(3);
			$("#dialog-loading").dialog("option", "title", "In progress... (" + [t.Hour, t.Minute, t.Second].join(":") + ")");
			return;
		}, 200);
		
		myworker.addEventListener("message", function(e){
			var c = JSON.parse(e.data);
			var t = {};
			var donemsg = "";
			
			if(c.msgtype === 0){
				$("#loadingmessage").text(c.msg);
				$("div.processbar-ratio").css("width", Number.parseInt(c.process * 250));
			} else if(c.msgtype === 1){
				myworker.terminate();
				result = c.result;
				timetag = c.timetag;
				clearInterval(elapseID);
				t = timer.stop(3);
				
				$("#dialog-loading").dialog("option", "title","Please wait...");
				
				donemsg = "The calculation of term statistics about terms - (Total Time:" + [t.Hour, t.Minute, t.Second].join(":") + ")：<br/><br/>";
				for(var i = 0, li = params.termlists.length; i < li; i++){
					donemsg = donemsg + "<span class='resultinfo-termlist'>" + params.termlists[i].name + "</span><br/>";
				}
				donemsg = donemsg + "in corpora -<br/>";
				for(var i = 0, li = params.corpusnames.length; i < li; i++){
					donemsg = donemsg + "<span class='resultinfo-corpus'>" + params.corpusnames[i] + "</span><br/>";
				}
				donemsg = donemsg + "<br/>has completed.";
				$("#termstat-result-info").html(donemsg);
				
				generateWordClouds(result.wordclouddata);
				
				$(".sidebar-flag").eq(4).click();
				stopLoading(0);
				$("#processbar").hide();
				$("#outputfile-byterm").removeAttr("disabled");
				$("#outputfile-byfile").removeAttr("disabled");
				$("#outputfile-xmldetail").attr("disabled", true);
			}
			return;
		});
		
		myworker.postMessage(params);
		return;
	};
	
	var runAnalysis_XmlTag = function(params){
		var myworker = new Worker("./js/worker_search.js");
		var timer = new Stopwatch(), elapseID = 0;
		
		$("#processbar-ratio").css("width", "0%");
		$("#processbar").show();
		startLoading();
		
		timer.start();
		elapseID = setInterval(function(){
			var t = timer.getTime(3);
			$("#dialog-loading").dialog("option", "title", "In progress... (" + [t.Hour, t.Minute, t.Second].join(":") + ")");
			return;
		}, 200);
		
		myworker.addEventListener("message", function(e){
			var c = JSON.parse(e.data);
			var t = {};
			var donemsg = "";
			
			if(c.msgtype === 0){
				$("#loadingmessage").text(c.msg);
			$("div.processbar-ratio").css("width", Number.parseInt(c.process * 250));
			} else if(c.msgtype === 1){
				myworker.terminate();
				result = c.result;
				timetag = c.timetag;
				clearInterval(elapseID);
				t = timer.stop(3);
				$("#dialog-loading").dialog("option", "title","Please wait...");
				
				donemsg = "The calculation of term statistics about terms in XML tags - (Total Time:" + [t.Hour, t.Minute, t.Second].join(":") + ")：<br/><br/>";
				for(var i = 0, li = params.xmltagginginfo.tagnames.length; i < li; i++){
					donemsg = donemsg + "<span class='resultinfo-termlist'>" + params.xmltagginginfo.tagnames[i] +
						((params.xmltagginginfo.filtermap[params.xmltagginginfo.tagnames[i]]) ? ("(filter by term list: " + params.xmltagginginfo.filtermap[params.xmltagginginfo.tagnames[i]] + ")") : "") +
						"</span><br/>";
				}
				donemsg = donemsg + "in corpora -<br/>";
				for(var i = 0, li = params.corpusnames.length; i < li; i++){
					donemsg = donemsg + "<span class='resultinfo-corpus'>" + params.corpusnames[i] + "</span><br/>";
				}
				donemsg = donemsg + "<br/>has completed.";
				$("#termstat-result-info").html(donemsg);
				
				generateWordClouds(result.wordclouddata);
				
				$(".sidebar-flag").eq(4).click();
				stopLoading(0);
				$("#processbar").hide();
				$("#outputfile-byterm").removeAttr("disabled");
				$("#outputfile-byfile").removeAttr("disabled");
				$("#outputfile-xmldetail").removeAttr("disabled");
			}
			return;
		});
		
		myworker.postMessage(params);
		return;
	};
	
	var generateWordClouds = function(data){
		var corpusname = "";
		var canvas = $("#termstat-wordcloud");
		
		canvas.find(".termstat-wordcloud-canvas").each(function(idx, elem){
			$(this).jQCloud("destroy");
		});
		canvas.empty();
		
		for(corpusname in data){
			if(data[corpusname] !== undefined && data[corpusname].length !== 0){
				canvas.append("<div class='termstat-wordcloud-block'><div class='termstat-wordcloud-title'>" + corpusname + "<button class='btn btn-normal termstat-wordcloud-saveimg' disabled='disabled'>Wait for render...</button></div><div class='termstat-wordcloud-canvas'></div></div>");
				canvas.find(".termstat-wordcloud-canvas").last().jQCloud(data[corpusname], {
					"fontSize": {"from": 0.15, "to": 0.0225},
					"autoResize": true,
					"delay": 10,
					"afterCloudRender": function(){
						var renderedelem = this;
						var wcblock = $(this).parent();
						wcblock.find(".termstat-wordcloud-saveimg").click(function(e){
							html2canvas(renderedelem, {
								"onrendered": function(renderedimg){
									renderedimg.toBlob(function(blob){
										saveAs(blob, corpusname + ".png");
										return;
									}, "image/png");
									return;
								}
							});
							return;
						}).text("Save as PNG").attr("disabled", false);
					}
				});
			} else {
				canvas.append("<div class='termlist-wordcloud-block'><div class='termstat-wordcloud-title'>No searched term in corpus 「" + corpusname + "」.</div><div class='termstat-wordcloud-canvas'> </div></div>");
			}
		}
		/*
		canvas.find(".termstat-wordcloud-saveimg").each(function(idx, elem){
			$(this).click(function(e){
				html2canvas(canvas.find(".termstat-wordcloud-canvas")[idx], {
					"onrendered": function(canvas){
						
					}
				})
			});
		});
		*/
	}
	
	this.saveFile = function(type){
		var i, j, k, li, lj, lk;
		var extrametalist = result.extrametas;
		var resultarr = [], resultstr = "", extrametastr = "";
		var dataelemlist = [], catresult = {}, docresult = {}, extrametaname = "", vocres = {}, wordres = {}, xmlres = {};
		var outputextrameta = $("#outputextrameta").is(":checked");
		var blob;
		
		switch(type){
			case "d":
				if(outputextrameta){
					for(i = 0, li = extrametalist.length; i < li; i++){
						extrametastr = extrametastr + addquo(extrametalist[i]) + ",";
					}					
				}
				resultarr.push('"category","file","title","source","docclass","order","passageid",' + extrametastr + '"termscount","totaloccurence","termlist","detail"');
				for(i = 0, li = result["categorizeddocumentresult"].length; i < li; i++){
					catresult = result["categorizeddocumentresult"][i];
					for(j = 0, lj = catresult["document-list"].length; j < lj; j++){
						docresult = catresult["document-list"][j];
						dataelemlist = [
							addquo(catresult["category-name"]),
							addquo(docresult["filename"]),
							addquo(docresult["title"]),
							addquo(docresult["source"]),
							addquo(docresult["docclass"]),
							addquo(docresult["order"]),
							addquo(docresult["passageid"])
						];
						if(outputextrameta){
							for(k = 0, lk = extrametalist.length; k < lk; k++){						
								extrametaname = extrametalist[k];
								dataelemlist.push(addquo(docresult["extrameta"][extrametaname]));
							}
						}
						dataelemlist = dataelemlist.concat([
							addquo(docresult["termscount"]),
							addquo(docresult["totaloccur"]),
							addquo(docresult["termlist"]),
							addquo(docresult["detail"])
						]);
						resultarr.push(removenewline(dataelemlist.join(",")));
					}
				}
				blob = new Blob(new Array(resultarr.join("\n")), {"type": "text/plain;charset=utf-8"});
				saveAs(blob, "Result_documents_" + timetag);
				break;
			case "t":
				resultarr.push('"category","word","tf","df"');
				for(i = 0, li = result["vocabularyresult"].length; i < li; i++){
					vocres = result["vocabularyresult"][i];
					for(j = 0, lj = vocres["category-list"].length; j < lj; j++){
						wordres = vocres["category-list"][j];
						resultstr = [
							addquo(vocres["category-name"]),
							addquo(wordres["word"]),
							addquo(wordres["tf"]),
							addquo(wordres["df"])
						].join(",");
						resultarr.push(removenewline(resultstr));	// 20170413
					}
				}
				blob = new Blob(new Array(resultarr.join("\n")), {"type": "text/plain;charset=utf-8"});
				saveAs(blob, "Result_documents_" + timetag);
				break;
			case "x":
				if(outputextrameta){
					for(i = 0, li = extrametalist.length; i < li; i++){
						extrametastr = extrametastr + addquo(extrametalist[i]) + ",";
					}					
				}
				resultarr.push('"filename","title","source","docclass","order","passageid",' + extrametastr + '"category-name","text","attr-details","freq"');
				for(i = 0, li = result["xmltagdetails"].length; i < li; i++){
					xmlres = result["xmltagdetails"][i];
					dataelemlist = [
						addquo(xmlres["filename"]),
						addquo(xmlres["title"]),
						addquo(xmlres["source"]),
						addquo(xmlres["docclass"]),
						addquo(xmlres["order"]),
						addquo(xmlres["passageid"])
					];
					
					if(outputextrameta){
						for(j = 0, lj = extrametalist.length; j < lj; j++){						
							extrametaname = extrametalist[j];
							dataelemlist.push(addquo(docresult["extrameta"][extrametaname]));
						}
					}
					dataelemlist = dataelemlist.concat([
						addquo(xmlres["category-name"]),
						addquo(xmlres["text"]),
						addquo(xmlres["attr-details"]),
						addquo(xmlres["freq"])
					]);
					
					resultarr.push(removenewline(dataelemlist.join(",")));
				}
				blob = new Blob(new Array(resultarr.join("\n")), {"type": "text/plain;charset=utf-8"});
				saveAs(blob, "Result_xmldetail_" + timetag);
				break;
			default:
				break;
		}
		return;
	};
})();