// Categorized Vocabulary List.
function VocabularyList(){
	// 'list' Structure: ["category-id" - {"category-name": (str), "category-content: (arr)", "category-idmap": (obj)}]
	// 'idxmap' Structure: {"categiry-name": (number)}
	var my = this;
	var list = [];
	var idxmap = {};
	var holelist = [];
	
	var prefix = "_";
	
	var getListLength = function(){
		return list.length;
	}
	
	var checkCategoryNameDuplication = function(n){
		if (idxmap[prefix + n] === undefined){
			return false;
		} else {
			return true;
		}
	}
	
	var calculateTermLen = function(arr){
		if(arr.length === 0){
			return({"min": 0, "max": 0});
		}
		var lenarr = [];
		for(var i = 0; i < arr.length; i++){
			if(lenarr[arr[i].length] === undefined){
				lenarr[arr[i].length] = 1
			};
		}
		return({"min": lenarr.indexOf(1), "max": (lenarr.length - 1)});
	}
	
	var assignCategoryIndex = function(){
		return (holelist.length === 0) ? getListLength() : holelist.shift();
	}
	
	var formIDMap = function(nl){
		/* If Array.prototype.reduce() is not supported
		for (var i = 0; i < nl.length; i++){
			result[nl[i]] = i;
		}
		return result;
		*/
		return nl.reduce(function(pv, cv, ci, a){
			pv[prefix + cv] = ci;
			return pv;
		} ,{});
	}
	
	var addConstructedCategory = function(n, c){		
		var idx = -1;
		var leninfo = calculateTermLen(c);
		if(checkCategoryNameDuplication(n)){
			return -1;
		} else {
			idx = assignCategoryIndex();
			list[idx] = {"category-name": n, "content": c, "idmap": formIDMap(c)};
			idxmap[prefix + n] = idx;
			return ({
				"index": idx,
				"minlen": leninfo.min,
				"maxlen": leninfo.max
			});
		}
	}
	
	var addEmptyCategory = function(n){
		var idx = -1;
		if(checkCategoryNameDuplication(n)){
			return -1;
		} else {
			idx = assignCategoryIndex();
			list[idx] = {"category-name": n, "content": [], "idmap": {}};
			idxmap[prefix + n] = idx;
			return idx;
		}
	}
	
	var addCategoryByCSV = function(n, c, s){
		if(checkCategoryNameDuplication(n)){
			return -1;
		} else {
			var content = c.split(s);
			// delete all blanks and empty string
			for(var i = 0; i < content.length; i++){
				content[i] = content[i].trim();
			}
			content.sort(function(a, b){
				if(a > b){
					return -1;
				} else if(a < b){
					return 1;
				} else {
					return 0;
				}
			});
			
			for(var i = 0; i < content.length; i++){
				if(content[i] === ""){
					content.splice(i);
					break;
				}
			}
			
			return addConstructedCategory(n, content);
		}
	}
	
	my.addCategory = function(){
		if(arguments.length === 3){
			return addCategoryByCSV(arguments[0], arguments[1], arguments[2]);
		} else if(arguments.length === 2){
			return addConstructedCategory(arguments[0], arguments[1]);
		} else if(arguments.length === 1){
			return addEmptyCategory(arguments[0]);
		} else {
			return -1;
		}
	}
	
	// Get array list of this category
	my.getCategoryListById = function(id){
		if(Number.isInteger(id) && id >= 0){
			return list[id]["content"];
		}
		return;	// return undefined
	}
		
	// Get the js object of this category
	my.getCategoryObjById = function(id){
		if(Number.isInteger(id) && id >= 0){
			return list[id];
		}
		return;
	}
	
	// Get array list of this category
	my.getCategoryListByName = function(name){
		var id = idxmap[prefix + name];
		if(id !== undefined){
			return list[id]["content"];
		} else {
			return;
		}
	}
	
	// Get the js object of this category
	my.getCategoryObjByName = function(name){
		var id = idxmap[prefix + name];
		if(id !== undefined){
			return list[id];
		} else {
			return;
		}
	}
	
	var renewCategoryListById = function(id, content){
		var leninfo = calculateTermLen(content);
		if((list[id] !== undefined) && checkarrallstr(content)){
			list[id]["content"] = content;
		}
		return leninfo;
	}
	
	var renewCategoryListByName = function(n, content){
		var leninfo = calculateTermLen(content);
		var idx = idxmap[prefix + n];
		if((idx !== undefined)  && checkarrallstr(content)){
			list[idx]["content"] = content;
		}
		return leninfo;
	}
	
	// May consider allowing csv renew
	my.renewCategoryList = function(arg, c){
		if(Number.isInteger(arg)){
			return renweCategoryListById(arg, c);
		} else if (typeof(arg) === "string"){
			return renewCategoryListByName(arg, c);
		}
	}
	
	var deleteCategoryListById = function(id){
		if(list[id] !== undefined){
			var name = list[id]["category-name"];
			// Remove from list and map
			list.splice(id, 1);
			delete idxmap[name];
			// Add this id to holelist
			holelist.push(id);
			return id;
		} else {
			return -1;
		}
	}
	
	var deleteCategoryListByName = function(n){
		var idx = idxmap[prefix + n];
		if(idx !== undefined){
			return deleteCategoryListById(idx);
		}
		return -1;
	}
	
	my.deleteCategoryList = function(arg){
		if(Number.isInteger(arg)){
			return deleteCategoryListById(arg);
		} else if(typeof(arg) === "string"){
			return deleteCategoryListByName(arg);
		}
		return -1;
	}
	
	// Retrieve a word in current categories
	my.findInCategory = function(s){
		var result = [];
		var category = {};
		var resultid = -1;
		
		for(var i = 0; i < list.length; i++){
			category = list[i];
			resultid = category["idmap"][prefix + s];
			if(resultid !== undefined){
				result.push({"category-id": i, "category-name": category["category-name"], "wordid": resultid, "word": category["content"][resultid]});
			}
		}
		return result;
	}
	
	// Get an array of CatId - CatName pair
	my.getIDNamePair = function(){
		var result = [];
		for(var elem in idxmap){
			result.push({"id": idxmap[elem], "name": elem.substr(prefix.length)});
		}
		result.sort(function(a, b){return a.id - b.id;});
		return result;
	}
	
	// Get an array with its categoryID corresponding array index if getIDNamePair() is used.
	// Empty categoryID has value 'undefined'.
	my.getIdArridxMap = function(){
		var result = [];
		var idx = 0;
		for(var elem in idxmap){
			result[idxmap[elem]] = idx;
			idx += 1;
		}
		return result;
	}
}

// Search Gram in Single Text.
function GramSearcher(){
	var normalizeText = function(text, punc){
		return depunch_2(text, punc);
	};
	
	var formNgramList = function(ntext, punc, min, max){
		var segments = ntext.split(punc);
		var segment = "";
		var tmpgram = "";
		var result = {};
		
		for(var i = 0; i < segments.length; i++){
			segment = segments[i];
			for(var j = min; j <= max; j++){
				for(var k = 0; k + j <= segment.length; k++){
					tmpgram = segment.substr(k, j);
					if(result[tmpgram]){
						result[tmpgram]["count"] += 1;
					} else {
						result[tmpgram] = {"gram": tmpgram, "length": tmpgram.length, "count": 1};
					}
				}
			}
		}
		
		return result;
	};
	
	this.searchGram = function(text, punc, clist, min, max){
		var min = (Number.isInteger(min) && min > 0) ? min : 2;
		var max = (Number.isInteger(max) && max > 0) ? (max > min) ? max : min : 20;
		var ngramlist = formNgramList(normalizeText(text, punc), punc, min, max);
		var result_normal = [], result_categorized = [];
		var i, li, j, lj;
		var elem_ngram, elem_termresult;
		var prev_catid = -1;
		
		for(elem_ngram in ngramlist){
			result_normal = result_normal.concat(clist.findInCategory(ngramlist[elem_ngram]["gram"]));
		}
		result_normal.sort(function(a, b){
			if(a["category-id"] > b["category-id"]){
				return 1;
			} else if (a["category-id"] < b["category-id"]){
				return -1;
			} else{
				return a["wordid"] - b["wordid"];
			}
		});
		
		for(i = 0, li = result_normal.length; i < li; i++){
			elem_termresult = result_normal[i];
			elem_termresult["freq"] = ngramlist[elem_termresult["word"]]["count"];	// add term frequency
			if(elem_termresult["category-id"] !== prev_catid){
				result_categorized.push({
					"category-id": elem_termresult["category-id"],
					"category-name": elem_termresult["category-name"],
					"word-list": []
				});
				prev_catid = elem_termresult["category-id"];
			}
			result_categorized[result_categorized.length - 1]["word-list"].push(elem_termresult);
		}
		// sort word-list by frequency
		for(i = 0, li = result_categorized.length; i < li; i++){
			result_categorized[i]["word-list"].sort(function(a, b){
				if(b.freq > a.freq){
					return 1;
				} else if(a.freq > b.freq){
					return -1;
				} else {
					return b.wordid - a.wordid;
				}
			});
		}
		
		return {"result-normal": result_normal, "result-categorized": result_categorized};
	};
}


// 20170321 Test Version

function GramSearcherXml(){
	var my = this;
	
	my.searchInXml = function(doc, filterinfo, vlist){
		var tagnamelist = filterinfo.tagnames || [];
		var taggings = doc.taggings || {};
		var filtermap = filterinfo.filtermap || {};
		var i, li, j, lj, key_tagname, elem_taggedlist, taggedcontentkey, taggedcontent, elem_result, result_word;
		var taggedterminfo = {};
		var result_normal = [], result_categorized = [];
		var prev_catid = "";	// 20170401: because we don't use findInCategory, we use tagname instead of category-id
		var termpool = {};	// 20170406: it is used to save non-repeated term set and their array index on result_normal.
		
		if(taggings === undefined || Object.keys(taggings).length === 0){
			return {"result-normal": [], "result-categorized": []};
		}
		
		for(key_tagname in taggings){
			if(tagnamelist.indexOf(key_tagname) >= 0){
				elem_taggedlist = taggings[key_tagname];
				for(taggedcontentkey in elem_taggedlist){
					taggedcontent = elem_taggedlist[taggedcontentkey];
					if(vlist[key_tagname] === undefined || vlist[key_tagname].findInCategory(taggedcontent.text).length !== 0){	// 1. no filter list, or 2. occur in filter list
						if(termpool[taggedcontent.text] === undefined){
							result_normal.push({ "word": taggedcontent.text, "category-name": key_tagname, "freq": 0, "attrsinfo": [] });
							termpool[taggedcontent.text] = result_normal.length - 1;
						}
						result_normal[termpool[taggedcontent.text]].freq += taggedcontent.freq;
						result_normal[termpool[taggedcontent.text]].attrsinfo.push({ "attrs": taggedcontent.attrs, "freq": taggedcontent.freq });
					}
				}
			}
		}
		
		// Sort result by id
		result_normal.sort(function(a, b){
			if(a["category-name"] > b["category-name"]){
				return 1;
			} else if (a["category-name"] < b["category-name"]){
				return -1;
			} else{
				return (a["word"] > b["word"]) ? 1 : (a["word"] < b["word"]) ? -1 : 0;
			}
		});
		
		for(i = 0, li = result_normal.length; i < li; i++){
			elem_result = result_normal[i];
			result_word = elem_result["word"];
			if(elem_result["category-name"] !== prev_catid){
				result_categorized.push({
					"category-name": elem_result["category-name"],
					"word-list": []
				});
				prev_catid = elem_result["category-name"];
			}
			result_categorized[result_categorized.length - 1]["word-list"].push(elem_result);
		}
		
		for(i = 0, li = result_categorized.length; i < li; i++){
			result_categorized[i]["word-list"].sort(function(a, b){
				return b.freq - a.freq;
			});
		}
		
		return { "result-normal": result_normal, "result-categorized": result_categorized };
	}
}